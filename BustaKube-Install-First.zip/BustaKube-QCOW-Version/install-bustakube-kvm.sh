#!/bin/bash

if [ ! -d /root/BustaKube-QCOW-Version ] ; then
    echo "The virtual machines' qcow files must be placed into /root/BustaKube-QCOW-Version."
    exit 1
fi

if [ ! -f /root/BustaKube-QCOW-Version/bustakube-controlplane.qcow2 ] ; then
    echo "The bustakube-controlplane.qcow2 file must be placed into /root/BustaKube-QCOW-Version."
    exit 2
fi

if [ ! -f /root/BustaKube-QCOW-Version/bustakube-node-1.qcow2 ] ; then
    echo "The bustakube-node-1.qcow2 file must be placed into /root/BustaKube-QCOW-Version."
    exit 3
fi

if [ ! -f /root/BustaKube-QCOW-Version/bustakube-node-2.qcow2 ] ; then
    echo "The bustakube-node-2.qcow2 file must be placed into /root/BustaKube-QCOW-Version."
    exit 4
fi


if [ ! -f /root/BustaKube-QCOW-Version/bustakube-controlplane.xml ] ; then
    echo "The bustakube-controlplane.xml file must be placed into /root/BustaKube-QCOW-Version."
    exit 5
fi

if [ ! -f /root/BustaKube-QCOW-Version/bustakube-node-1.xml ] ; then
    echo "The bustakube-node-1.xml file must be placed into /root/BustaKube-QCOW-Version."
    exit 6
fi

if [ ! -f /root/BustaKube-QCOW-Version/bustakube-node-2.xml ] ; then
    echo "The bustakube-node-2.xml file must be placed into /root/BustaKube-QCOW-Version."
    exit 7
fi

if [ ! -f /root/BustaKube-QCOW-Version/kvm-network.xml ] ; then
    echo "The kvm-network.xml file must be placed into /root/BustaKube-QCOW-Version."
    exit 8
fi


echo "Installing KVM with QEMU and virt-manager"
apt -y update
apt -y install qemu-kvm libvirt-clients libvirt-daemon-system virt-manager

echo "Applying a NAT network from kvm-network.xml"
virsh net-destroy default
virsh net-undefine default
virsh net-define /root/BustaKube-QCOW-Version/kvm-network.xml
virsh net-autostart default
virsh net-start default

echo "Configuring the first virtual machine from bustakube-controlplane.xml"
virsh define /root/BustaKube-QCOW-Version/bustakube-controlplane.xml 
echo "Configuring the second virtual machine from bustakube-node-1.xml"
virsh define /root/BustaKube-QCOW-Version/bustakube-node-1.xml
echo "Configuring the third virtual machine from bustakube-node-2.xml"
virsh define /root/BustaKube-QCOW-Version/bustakube-node-2.xml 

echo "If everything has gone correctly, you have a cluster of machines all ready for you.  Run virt-manager to get a GUI."
